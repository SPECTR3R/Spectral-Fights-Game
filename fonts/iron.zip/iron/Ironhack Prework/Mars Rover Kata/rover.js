/*jshint esversion: 6 */

// Iteration 1 | Create Rover Object with direction property
// Iteration 3 | Add x and y, position properties
const rover1 = {
    protoNumber : 1,   // Bonus 4 | add property to diferentiate other rovers from others
    direction: "N",
    x: 0,
    y: 0,
    moves:0,
    travelLog: []
};
// ======================

// Bonus 4 | add other rover
const rover2 = {
    protoNumber : 2,   // Bonus 4 | add property to diferentiate other rovers from others
    direction: "N",
    x: 0,
    y: 0,
    moves:0,
    travelLog: []
};
// ======================

// Iteration 2 | create functions to turn the Rover  Left or Right
function turnRight(rover) {
    let directions = "NESW", newDir, CurrentDir = rover.direction;
    if (CurrentDir === "W") newDir = "N";
    else newDir = directions[directions.indexOf(CurrentDir) + 1];
    console.log(`Rover was facing ${CurrentDir} and turned Right => Rover is now facing ${newDir}`);
    rover.direction = newDir;
}

function turnLeft(rover) {
    let directions = "NESW", newDir, currentDir = rover.direction;
    if (currentDir === "N") newDir = "W";
    else newDir = directions[directions.indexOf(currentDir) - 1];
    console.log(`Rover was facing ${currentDir} and turned Left => Rover is now facing ${newDir}`);
    rover.direction = newDir;
}
// ======================

// Iteration 3 |Create moveForward function
// Bonus 1 | Avoid the rover to leave the grid
function moveForward(rover) {
    let currentX = rover.x, currentY = rover.y, newX, newY;
    switch (rover.direction) {
        case "N":
            if (currentY === 0) {
                console.log(`Rover is in (x:${currentX},y:${currentY}) position, facing ${rover.direction}, can't move forward`);
                return;
            } else {
                newY = currentY - 1;
                newX = currentX;
            }
            break;
        case "S":
            if (currentY === 9) {
                console.log(`Rover is in (x:${currentX},y:${currentY}) position, facing ${rover.direction}, can't move forward`);
                return;
            } else {
                newY = currentY + 1;
                newX = currentX;
            }
            break;
        case "E":
            if (currentX === 9) {
                console.log(`Rover is in (x:${currentX},y:${currentY}) position, facing ${rover.direction}, can't move forward`);
                return;
            } else {
                newY = currentY;
                newX = currentX+1;
            }
            break;
        default:
            if (currentX === 0) {
                console.log(`Rover is in (x:${currentX},y:${currentY}) position, facing ${rover.direction}, can't move forward`);
                return;
            } else {
                newY = currentY;
                newX = currentX-1;
            }
            break;
    }
    console.log(`Rover was in (x:${currentX},y:${currentY}) position, facing ${rover.direction}, and it moved forward => Rover is now at(x:${newX},y:${newY})`);
    rover.x = newX;
    rover.y = newY;
}
// ======================

// Bonus 2 |Create moveBackward function
function moveBackward(rover) {
    let currentX = rover.x, currentY = rover.y, newX, newY;
    switch (rover.direction) {
        case "N":
            if (currentY === 9) {
                console.log(`Rover is in (x:${currentX},y:${currentY}) position, facing ${rover.direction}, can't move forward`);
                return;
            } else {
                newY = currentY+1;
                newX = currentX;
            }
            break;
        case "S":
            if (currentY === 0) {
                console.log(`Rover is in (x:${currentX},y:${currentY}) position, facing ${rover.direction}, can't move forward`);
                return;
            } else {
                newY = currentY - 1;
                newX = currentX;
            }
            break;
        case "E":
            if (currentX === 0) {
                console.log(`Rover is in (x:${currentX},y:${currentY}) position, facing ${rover.direction}, can't move forward`);
                return;
            } else {
                newY = currentY;
                newX = currentX - 1;
            }
            break;
        default: //case "W"
            if (currentX === 9) {
                console.log(`Rover is in (x:${currentX},y:${currentY}) position, facing ${rover.direction}, can't move forward`);
                return;
            } else {
                newY = currentY;
                newX = currentX+1;
            }
            break;
    }
    console.log(`Rover was in (x:${currentX},y:${currentY}) position, facing ${rover.direction}, and it moved forward => Rover is now at(x:${newX},y:${newY})`);
    rover.x = newX;
    rover.y = newY;
}
// ======================

// Iteration 4 | Create commandRover function
// Iteration 5 | Update travelLog
let commandRover = (commandStr, rover, intialX = 0, intialY = 0) => {
    if (!commandStr){
        console.log("Please provide a valid list of commands in lowercase...Abort operation");
        return;
    }
    let commands = commandStr.split("");
    console.log(`processing ${commands.length} steps`);
    for (let i = 0; i <= commands.length - 1; i++){ // Bonus 3 | Validate Inputs
        if (commands[i] !== "f" && commands[i] !== "b" && commands[i] !== "r" && commands[i] !== "l") {
            console.log("Please provide a valid list of commands in lowercase...Abort operation");
            return;
        }
    }
    console.log(`Input validated... Rover ${rover.protoNumber} is moving!`);
    commands.forEach((command,move) => {
        switch (command) {
            case "f":
                moveForward(rover);
                rover.travelLog.push([`step ${move+1}: (x:${rover.x},x:${rover.y})`]);
                break;
            case "b":
                moveBackward(rover);
                rover.travelLog.push([`step ${move+1}: (x:${rover.x},x:${rover.y})`]);
                break;
            case "r":
                turnRight(rover);
                rover.travelLog.push([`step ${move+1}: (x:${rover.x},x:${rover.y})`]);
                break;
            default:
                turnLeft(rover);
                rover.travelLog.push([`step ${move+1}: (x:${rover.x},x:${rover.y})`]);
                break;
        }
    });
};
// ======================

commandRover("rfffffffffffrfrff",rover1);

console.log(rover1);
