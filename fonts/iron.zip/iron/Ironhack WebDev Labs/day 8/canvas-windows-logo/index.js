const canvas = document.querySelector('canvas');
const ctx = canvas.getContext('2d');

ctx.fillStyle = 'rgb(187, 50, 50)';
ctx.fillRect(0, 0, 100, 100);
ctx.fillStyle = 'red';
ctx.fillRect(25, 25, 75, 75);
ctx.fillStyle = 'rgb(238, 68, 68)';
ctx.fillRect(50, 50, 50, 50);


ctx.fillStyle = ' rgb(21, 134, 21)';
ctx.fillRect(105, 0, 100, 100);
ctx.fillStyle = 'rgb(41, 204, 41)';
ctx.fillRect(105, 25, 75, 75);
ctx.fillStyle = 'rgb(145, 248, 145)';
ctx.fillRect(105, 50, 50, 50);


ctx.fillStyle = 'rgb(17, 36, 124)';
ctx.fillRect(0, 105, 100, 100);
ctx.fillStyle = 'rgb(38, 67, 196)';
ctx.fillRect(25, 105, 75, 75);
ctx.fillStyle = 'rgb(63, 96, 245)';
ctx.fillRect(50, 105, 50, 50);

ctx.fillStyle = 'rgb(134, 158, 25)';
ctx.fillRect(105, 105, 100, 100);
ctx.fillStyle = 'rgb(201, 198, 49)';
ctx.fillRect(105, 105, 75, 75);
ctx.fillStyle = 'rgb(255, 253, 107)';
ctx.fillRect(105, 105, 50, 50);


/*
ctx.fillStyle = 'yellow';
ctx.fillRect(100, 100, 100, 100);

ctx.fillStyle = 'blue';
ctx.fillRect(0, 100, 100, 100);

ctx.fillStyle = 'green';
ctx.fillRect(100, 0, 100, 100);
*/