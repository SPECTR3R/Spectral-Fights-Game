# Half Diamond Asterisk Pattern in JS using a single forEach Iterator
