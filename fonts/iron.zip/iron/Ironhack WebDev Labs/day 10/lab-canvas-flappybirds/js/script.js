const canvas = document.querySelector('canvas');
const ctx = canvas.getContext('2d');

class Board {
  constructor() {
    this.img = new Image();
    this.img.src = './images/bg.png';
    this.y = 0;
    this.x = 0;
    this.width = canvas.width;
    this.height = canvas.height;
    this.speed = 1;
    this.interval = undefined;
    this.frames = 100;
    this.img.onload = () => {
      this.draw();
      this.loadScreen();
    };
  }
  draw() {
    this.x--;
    if (this.x < -this.width) this.x = 0;
    ctx.drawImage(this.img, this.x, this.y, this.width, this.height);
    ctx.drawImage(this.img, this.x + this.width, this.y, this.width, this.height);
  }
  loadScreen() {
    const logo = new Image();
    logo.src = './images/logo.png';
    ctx.drawImage(logo, 100, 60, 300, 100);
    ctx.font = '30px Samanata';
    ctx.fillText('Press start!', 160, 200);
  }
  gameOver() {
    clearInterval(this.interval);
  }
  ruler() {
    canvas.addEventListener('mousedown', function (clientX) {
      let rect = canvas.getBoundingClientRect();
      let clickX = event.clientX - rect.left;
      let clickY = event.clientY - rect.top;
      console.log(`clicked on (${Math.floor(clickX)},${Math.floor(clickY)})`);
    });
  }
}

class Flappy {
  constructor() {
    this.x = 75;
    this.y = 150;
    this.img = new Image();
    this.img.src = './images/flappy.png';
    this.height = 35;
    this.width = 50;
  }
  draw() {
    ctx.drawImage(this.img, this.x, this.y, this.width, this.height);
    this.y + this.height >= canvas.height ? (this.y = canvas.height - this.height) : (this.y += 2);
  }
  fly() {
    this.y -= 30;
  }
  crash(obstacle) {
    if (
      obstacle.x < this.x + this.width &&
      obstacle.x + obstacle.width > this.x &&
      obstacle.y < this.y + this.height &&
      obstacle.height + obstacle.y > this.y
    )
      return true;
  }
}

class Pipes {
  constructor() {
    this.width = 20;
    this.height = 20;

    this.upperX = 500;
    this.lowerX = 500;
    this.img = new Image();
    this.img.src = './images/flappy.png';



    this.upperY = 120;
    this.lowerY = 200;

    this.score = 0;
    this.pipesOnScreen = [{}];
  }

  draw() {
    this.y++;
   
    this.context.fillRect(this.x, this.y, this.width, this.height);
  }

  randomNumber(max, min) {
    return Math.floor(Math.random() * (max - min) + min);
  }
}

// Instances
const board = new Board(canvas);
const flappy = new Flappy();
board.ruler(canvas);

// Aux variables

// Listeners
document.addEventListener('keydown', ({ keyCode }) => {
  if (keyCode === 32) flappy.fly();
});
window.onload = () => {
  document.getElementById('start-button').onclick = () => startGame();
};

// main functions
const startGame = () => {
  if (board.interval) return;
  board.interval = setInterval(updategame, 1000 / 60);
};

const updategame = () => {
  board.draw();
  flappy.draw();
};
